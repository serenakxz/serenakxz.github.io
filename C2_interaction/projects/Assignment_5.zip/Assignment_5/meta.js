console.log("hello");

let oneContainer = document.getElementById("one");
let recipeOne = document.createElement("div");
oneContainer.appendChild(recipeOne);


function makeTea(water,milk,tealeaf,sugar,pot){
    console.log("We are going to boil"+ water+ " ounces of water with" + tealeaf + "in a "+ pot + " ounce pot."+ "Add " + milk +" ounce of milk with " + sugar+ " ounce of sugar after cooling down.");
    recipeOne.innerHTML = "We are going to boil "+ water+ " ounces of water with " + tealeaf + " onunce tealeves in a "+ pot + " ounce pot. "+ "Add " + milk +" ounce of milk with " + sugar+ " ounce of sugar and keeps boiling for a while. Enjoy it after cooling down.";
}

makeTea(30,30,3,1,120);

let twoContainer = document.getElementById("two");
let recipeTwo = document.createElement("div");
twoContainer.appendChild(recipeTwo);

let imgBeef = new Image();
imgBeef.src = "beef.png";
twoContainer.appendChild(imgBeef);

let meat1 = "ground beef+ ";
let veg1 = "lettuce+ ";
let bread1 = "whole wheat bread+ ";
let cheese1 ="cheddar+ ";
function makeBurger(meat, vegetable, cheese, bread){
    let burger = bread+cheese+vegetable+meat+bread;
    return burger;
}
let cheeseBurger = makeBurger(meat1, veg1, cheese1, bread1);
console.log (cheeseBurger);
recipeTwo.innerHTML = cheeseBurger;
